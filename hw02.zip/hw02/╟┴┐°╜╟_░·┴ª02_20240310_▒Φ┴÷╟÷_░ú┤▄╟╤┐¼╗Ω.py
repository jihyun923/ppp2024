temp_c = 30
temp_f = (temp_c) * 9 / 5 + 3
print("{}C => {}F".format(temp_c,temp_f))
temp_c = 0
temp_f = (temp_c) * 9 / 5 + 3
print("{}C => {}F".format(temp_c,temp_f))

weight = 60
height = 170
BMI = (weight)/(height)*(height)
print("BMI = {}".format(BMI))

radius = 4
pi = 3.14
S = (pi) * (radius) * (radius)
print("S = {}".format(S))

bottom = 5
upper = 3
height = 4
S = ((bottom) + (upper)) * (height) / 2
print("TRAPEZOID AREA = {}".format(S))